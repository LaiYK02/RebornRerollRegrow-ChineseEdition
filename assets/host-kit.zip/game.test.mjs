import assert from "node:assert/strict";
import test from "node:test";
import { act, newGame, restoreGame, setOnline, view } from "./game.mjs";
import { cards } from "./cards.mjs";

const solo = () => newGame([{ id: "a", name: "甲" }]);
const pair = () =>
  newGame([
    { id: "a", name: "甲" },
    { id: "b", name: "乙" },
  ]);
const actor = (game) => view(game, game.turn).actor;
const choose = (game, action, rng = () => 0) =>
  act(game, actor(game), action, rng);
function step(game, action, rng = () => 0) {
  choose(game, action, rng);
  const available = ids(game).filter((id) => id !== "surrender");
  if (
    available.length === 1 &&
    ["check:accept", "confirm"].includes(available[0])
  )
    choose(game, available[0], rng);
}
const die = (n) => () => (n - 0.5) / 6;
const ids = (g, id = actor(g)) => view(g, id).actions.map((a) => a.id);

test("跨步符也须通过雨林判定，香蕉皮截停确认后的移动并结算落点", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 55;
  p.items = ["i05"];
  choose(g, "use:i05", die(2));
  assert.equal(p.pos, 55);
  choose(g, "check:accept");
  assert.equal(p.pos, 55);
  assert.deepEqual(p.items, ["i05"]);
  step(g, "end");
  choose(g, "use:i05", die(3));
  assert.equal(p.pos, 55);
  choose(g, "check:accept");
  assert.equal(p.pos, 56);
  assert.equal(g.check, null);
  const h = solo(),
    [q] = h.players;
  q.pos = 2;
  h.board[5].banana = true;
  h.board[7].banana = true;
  choose(h, "roll", die(6));
  assert.equal(q.pos, 2);
  choose(h, "check:accept");
  assert.equal(q.pos, 6);
  assert.equal(h.phase, "offer");
  assert.equal(h.board[5].banana, undefined);
  assert.equal(h.board[7].banana, true);
  assert.deepEqual(q.statuses, []);
});

test("雨林回城道具要过判定，成功回城没有升级", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 57;
  p.items = ["i11"];
  step(g, "use:i11", die(1));
  assert.equal(p.pos, 57);
  assert.deepEqual(p.items, ["i11"]);
  step(g, "end");
  step(g, "use:i11", die(6));
  assert.equal(p.pos, 1);
  assert.deepEqual(p.items, []);
  assert.equal(g.upgrades.length, 0);
});

test("休息格掷出 4 时既不升级也不回血", () => {
  const g = solo(),
    [p] = g.players;
  p.hp = 4;
  g.phase = "rest";
  choose(g, "rest", die(4));
  assert.equal(g.check.total, 4);
  choose(g, "check:accept");
  assert.equal(g.phase, "end");
  assert.equal(g.upgrades.length, 0);
  assert.equal(p.hp, 4);
});

test("怪物战确认放弃才会死亡回城，必须分配升级并处理弃牌", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 3;
  p.gear = ["l02"];
  step(g, "roll", die(1));
  assert.throws(() => choose(g, "confirmSurrender"));
  choose(g, "surrender");
  assert.deepEqual(ids(g), ["confirmSurrender", "cancelSurrender"]);
  assert.equal(p.pos, 4);
  choose(g, "cancelSurrender");
  assert.equal(g.battle.phase, "attack");
  assert.equal(p.hp, 10);
  choose(g, "surrender");
  choose(g, "confirmSurrender");
  assert.equal(p.pos, 1);
  assert.equal(p.hp, 10);
  assert.equal(g.battle, null);
  assert.equal(view(g, p.id).phase, "upgrade");
  assert.throws(() => choose(g, "discard:l02"));
  step(g, "upgrade:act");
  assert.equal(p.act, 2);
  step(g, "discard:l02");
  assert.deepEqual(p.gear, []);
});

test("旧存档的未分配升级必须逐次分配，保留原卡和已升属性", () => {
  const g = solo(),
    [p] = g.players;
  g.rulesVersion = 3;
  delete g.upgrades;
  p.sp = 2;
  p.atk = 2;
  p.alloc.atk = 1;
  p.items = ["i03"];
  restoreGame(g);
  assert.equal("sp" in p, false);
  assert.throws(() => choose(g, "roll"));
  step(g, "upgrade:def");
  step(g, "upgrade:act");
  assert.deepEqual([p.atk, p.def, p.act], [2, 2, 2]);
  assert.deepEqual(p.items, ["i03"]);
  assert.equal(view(g, p.id).phase, "move");
});

test("沙漠同格先交锋，只由挑战者结算落点", () => {
  const g = pair(),
    [p, q] = g.players;
  p.pos = 28;
  q.pos = 30;
  step(g, "roll", die(2));
  assert.equal(g.phase, "skirmish");
  assert.deepEqual([p.pos, q.pos], [30, 30]);
  step(g, "clash", die(6));
  step(g, "clash", die(2));
  assert.deepEqual([p.pos, q.pos], [29, 29]);
  assert.equal(g.actor, p.id);
  assert.equal(g.phase, "offer");
});

test("奇偶符只替换判定奇偶，移动仍使用原点数", () => {
  const g = solo(),
    [p] = g.players;
  p.gear = ["c07"];
  choose(g, "roll", die(3));
  assert.equal(g.dice.total, 3);
  assert.equal(g.dice.parity, "even");
  choose(g, "check:accept");
  assert.equal(p.pos, 4);
});

test("挑战者交锋落败或被装备推开时，结算退到的格子", () => {
  const g = pair(),
    [entrant, incumbent] = g.players;
  entrant.pos = 6;
  incumbent.pos = 7;
  step(g, "roll", die(1));
  step(g, "clash", die(1));
  step(g, "clash", die(6));
  assert.equal(entrant.pos, 6);
  assert.equal(g.phase, "offer");
  assert.deepEqual(ids(g, incumbent.id), []);

  const h = pair(),
    [challenger, defender] = h.players;
  challenger.pos = 7;
  defender.pos = 8;
  defender.gear = ["c11"];
  step(h, "roll", die(1));
  assert.equal(challenger.pos, 6);
  assert.equal(defender.pos, 8);
  assert.equal(h.phase, "offer");
  assert.deepEqual(ids(h, defender.id), []);
});

test("the board has 100 positions, symmetric portals and 25 active tiles per terrain", () => {
  const g = pair();
  assert.deepEqual(
    g.board.map((t) => t.pos),
    Array.from({ length: 100 }, (_, i) => i + 1),
  );
  assert.equal(g.board[0].type, "start");
  assert.equal(g.board.at(-1).type, "finish");
  assert.equal(g.board[6].type, "duel");
  assert.equal(g.board[15].type, "duel");
  const bosses = g.board.filter((t) => t.type === "boss");
  assert.deepEqual(bosses.map((t) => t.boss).sort(), [
    "b01",
    "b02",
    "b03",
    "b04",
    "b05",
    "b06",
    "b07",
  ]);
  assert.ok(bosses.every((t) => t.monster === t.boss));
  assert.ok(bosses[0].pos > 25);
  for (const tile of g.board.filter((t) => t.type === "portal"))
    assert.equal(g.board[tile.to - 1].to, tile.pos);
  for (const region of ["plain", "desert", "rainforest", "volcano"]) {
    assert.equal(g.board.filter((t) => t.biome === region).length, 25);
    assert.equal(
      g.board.filter((t) => t.biome === region && t.terrain === region).length,
      25,
    );
  }
  assert.deepEqual(
    g.players.map((p) => [p.pos, p.hp, p.atk, p.def, p.act]),
    [
      [1, 10, 1, 1, 1],
      [1, 10, 1, 1, 1],
    ],
  );
  assert.throws(() => act(g, "b", "roll"));
  assert.throws(() => act(g, "a", "not-an-action"));
  assert.doesNotThrow(() => structuredClone(JSON.parse(JSON.stringify(g))));
});

test("宝箱独立分级，确认掷骰后才移动或抽装备", () => {
  for (const [position, roll, type, prefix] of [
    [5, 1, "chest", "c"],
    [28, 2, "chest", "c"],
    [81, 1, "legendaryChest", "l"],
  ]) {
    const g = solo(),
      [p] = g.players;
    p.pos = position;
    choose(g, "roll", die(roll));
    assert.equal(p.pos, position);
    assert.ok(ids(g).includes("check:accept"));
    step(g, "check:accept", die(6));
    assert.equal(g.board[p.pos - 1].type, type);
    assert.equal(g.phase, "offer");
    const options = view(g, "a").actions;
    assert.equal(options.length, 4);
    assert.ok(options.some(({ id }) => id === "passOffer"));
    assert.ok(
      options
        .filter(({ card }) => card)
        .every(
          ({ card }) =>
            cards[card].kind === (prefix === "c" ? "普通装备" : "传说装备"),
        ),
    );
    step(g, "passOffer");
    assert.equal(g.phase, "end");
    assert.deepEqual(p.gear, []);
    assert.ok(
      g.board
        .filter((t) => t.type === "legendaryChest")
        .every((t) => t.biome === "volcano"),
    );
  }
});

test("旧单人存档保留进度，并升级火山宝箱和宝箱待选装备", () => {
  const g = solo();
  g.board[81].type = "chest";
  g.board[81].terrain = "plain";
  g.players[0].pos = 82;
  g.players[0].hp = 7;
  g.phase = "offer";
  g.pending = { ids: ["c01", "l01", "c02"] };
  restoreGame(g, die(3));
  assert.equal(g.players[0].pos, 82);
  assert.equal(g.players[0].hp, 7);
  assert.equal(g.board[81].type, "legendaryChest");
  assert.equal(g.board[81].terrain, "volcano");
  assert.ok(
    view(g, "a")
      .actions.filter(({ card }) => card)
      .every(({ card }) => cards[card].kind === "传说装备"),
  );
});

test("确认移动后记录沙漠的逐格前进与后退，火山传送到达也计伤害", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 25;
  choose(g, "roll", die(1));
  assert.equal(p.pos, 25);
  choose(g, "check:accept");
  assert.deepEqual(
    view(g, "a").movements.map(({ from, to, stepwise }) => [
      from,
      to,
      stepwise,
    ]),
    [
      [25, 26, true],
      [26, 25, false],
    ],
  );
  const h = solo(),
    [q] = h.players;
  q.pos = 89;
  step(h, "roll", die(1));
  assert.equal(q.pos, 76);
  assert.equal(q.hp, 8);
});

test("draws and unplayed items stay private and snapshots do not mutate authority", () => {
  const g = pair(),
    [, guest] = g.players;
  guest.items.push("i13");
  step(g, "roll", die(2));
  const a = view(g, "a"),
    b = view(g, "b");
  assert.equal(a.actions.length, 4);
  assert.equal(
    new Set(a.actions.filter((a) => a.card).map((a) => a.card)).size,
    3,
  );
  assert.deepEqual(b.actions, []);
  assert.equal(a.players[1].items, undefined);
  assert.equal(a.players[1].itemCount, 1);
  assert.ok(!JSON.stringify(a).includes("i13"));
  const item = a.actions[0].card;
  step(g, a.actions[0].id);
  const observer = view(g, "b");
  assert.equal(observer.players[0].itemCount, 1);
  assert.ok(!observer.log.some((line) => line.includes(cards[item].name)));
  a.players[0].gear.push("l03");
  assert.deepEqual(g.players[0].gear, []);
});

test("movement die modifiers, golden die, reroll and fate prism resolve once", () => {
  const g = solo(),
    [p] = g.players;
  p.gear = ["c03", "c06", "c07"];
  p.items = ["i18", "i09", "i08", "i01", "i19"];
  p.movePenalty = -2;
  step(g, "use:i09");
  step(g, "use:i18");
  step(g, "target:5");
  step(g, "roll", die(2));
  assert.deepEqual(g.dice.values, [5, 2]);
  assert.equal(g.dice.total, 7);
  step(g, "use:i08", die(1));
  assert.deepEqual(g.dice.values, [1, 1]);
  step(g, "use:i01");
  assert.deepEqual(g.dice.values, [6, 6]);
  step(g, "use:i19");
  choose(g, "target:-2");
  step(g, "check:accept");
  assert.equal(p.pos, 11);
  assert.equal(p.movePenalty, 0);
  assert.equal(p.items.length, 0);
});

test("terrain, traps, portals, heals and rest upgrades resolve at their proper times", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 27;
  step(g, "roll", die(1));
  assert.equal(p.pos, 27);
  assert.equal(g.battle.monster, "n01");
  const h = solo(),
    [q] = h.players;
  q.pos = 55;
  step(h, "roll", die(2));
  assert.equal(q.pos, 55);
  assert.equal(h.phase, "end");
  step(h, "end");
  step(h, "roll", die(3));
  assert.equal(h.phase, "move");
  step(h, "roll", die(3));
  assert.equal(q.pos, 58);
  step(h, "rest", die(5));
  assert.equal(q.def, 1);
  assert.deepEqual(ids(h), ["upgrade:atk", "upgrade:def", "upgrade:act"]);
  step(h, "upgrade:def");
  assert.equal(q.def, 2);
  assert.equal(q.alloc.def, 1);
  step(h, "end");
  q.pos = 79;
  q.hp = 5;
  step(h, "roll", die(1));
  assert.equal(q.hp, 4);
  step(h, "end");
  q.pos = 79;
  q.gear.push("l10", "l11");
  step(h, "roll", die(1));
  assert.equal(q.hp, 5);
  step(h, "end");
  q.pos = 32;
  step(h, "roll", die(2));
  assert.equal(q.pos, 15);
  assert.equal(h.phase, "end");
  step(h, "end");
  q.pos = 1;
  h.board[1].banana = true;
  step(h, "roll", die(1));
  assert.equal(q.pos, 2);
  assert.equal(h.board[1].banana, undefined);
  step(h, "end");
  step(h, "roll", die(6));
  assert.equal(q.pos, 8);
  assert.deepEqual(q.statuses, []);
});

test("barricades, ties in same-space clashes and duels at distant sites", () => {
  const g = pair(),
    [p, q] = g.players;
  q.pos = 2;
  step(g, "roll", die(1));
  assert.equal(g.phase, "skirmish");
  step(g, "clash", die(3));
  step(g, "clash", die(3));
  assert.equal(g.actor, "a");
  step(g, "clash", die(4));
  step(g, "clash", die(2));
  assert.deepEqual([p.pos, q.pos], [2, 1]);
  const h = pair(),
    [a, b] = h.players;
  a.pos = 4;
  b.pos = 5;
  b.gear = ["c11"];
  step(h, "roll", die(1));
  assert.equal(a.pos, 3);
  const j = pair(),
    [c, d] = j.players;
  c.pos = 10;
  d.pos = 24;
  d.gear = ["c10", "l03"];
  c.hp = 2;
  c.gear = ["l15", "l07"];
  c.items = ["i02"];
  step(j, "roll", die(1));
  assert.equal(j.battle.actorId, "b");
  for (let i = 0; i < 20 && j.battle; i++) step(j, ids(j)[0], die(3));
  assert.equal(j.phase, "loot");
  assert.equal(j.actor, "b");
  assert.equal(actor(j), "a");
  step(j, "upgrade:def");
  assert.equal(actor(j), "b");
  step(j, "upgrade:atk");
  assert.equal(c.pos, 1);
  assert.equal(c.hp, 10);
  assert.deepEqual(c.gear, ["l15", "l07"]);
  assert.deepEqual(ids(j, "a"), []);
  assert.ok(!JSON.stringify(view(j, "b")).includes("i02"));
  assert.ok(ids(j).includes("loot-item:0"));
  step(j, "loot:l07");
  assert.ok(d.gear.includes("l07"));
  assert.deepEqual(c.gear, ["l15"]);
  step(j, "end");
  assert.equal(j.turn, "b");
  const k = pair();
  k.players[0].pos = 10;
  k.players[1].pos = 24;
  k.players[1].gear = ["l08"];
  step(k, "roll", die(1));
  assert.equal(k.battle, null);
});

test("monster damage persists on escape, resets on death and grants all tier rewards", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 18;
  p.atk = 6;
  p.act = 2;
  p.items = ["i04"];
  step(g, "roll", die(1));
  assert.equal(g.battle.monster, "e01");
  step(g, "attack", die(4));
  assert.equal(g.battle.hp, 2);
  step(g, "use:i04");
  assert.equal(g.board[18].hp, 2);
  assert.equal(g.upgrades.length, 0);
  step(g, "end");
  p.pos = 18;
  step(g, "roll", die(1));
  assert.equal(g.battle.hp, 2);
  p.hp = 1;
  p.atk = 1;
  p.act = 1;
  p.gear = ["l03", "l08"];
  p.locked = ["l03"];
  for (let i = 0; i < 12 && g.battle; i++) step(g, ids(g)[0], die(2));
  assert.equal(p.pos, 1);
  assert.equal(p.hp, 10);
  assert.equal(g.board[18].hp, 3);
  assert.equal(g.phase, "deathDiscard");
  step(g, "upgrade:def");
  step(g, "discard:l08");
  assert.deepEqual(p.gear, ["l03"]);
  for (const [pos, tier] of [
    [4, "normal"],
    [19, "elite"],
    [32, "boss"],
  ]) {
    const h = solo(),
      [q] = h.players;
    q.pos = pos - 1;
    q.gear = ["l03", "c10", "l02"];
    q.act = 12;
    step(h, "roll", die(pos > 25 ? 2 : 1));
    assert.equal(h.board[pos - 1].type, tier);
    for (let i = 0; i < 40 && h.battle; i++) step(h, ids(h)[0], die(2));
    assert.equal(h.phase, "offer");
    assert.equal(h.upgrades.length, 0);
    const offered = () =>
      view(h, "a").actions.flatMap((a) => (a.card ? [a.card] : []));
    if (tier !== "normal") {
      assert.equal(offered().length, 3);
      assert.ok(offered().every((id) => cards[id].kind === "传说装备"));
      step(h, "passOffer");
      assert.equal(offered().length, 3);
    }
    assert.ok(offered().every((id) => cards[id].kind === "道具"));
    assert.equal(h.board[pos - 1].monster, h.board[pos - 1].boss);
  }
});

test("equipment replacement, badge withdrawal, bag loss, parity conflict and item cap", () => {
  const g = solo(),
    [p] = g.players;
  function offer(id) {
    g.phase = "offer";
    g.pending = { ids: [id] };
    step(g, "take:" + id);
  }
  offer("c13");
  assert.equal(view(g, p.id).phase, "upgrade");
  step(g, "upgrade:atk");
  assert.equal(p.atk, 2);
  offer("c07");
  offer("l16");
  offer("c08");
  assert.ok(ids(g).includes("replace:c07"));
  assert.ok(!ids(g).includes("replace:c13"));
  step(g, "replace:c07");
  offer("c04");
  step(g, "replace:c13");
  assert.equal(p.atk, 1);
  p.items = ["i01", "i02", "i03", "i05", "i08", "i09"];
  offer("i18");
  assert.equal(p.items.length, 7);
  offer("c13");
  step(g, "replace:l16");
  step(g, "upgrade:def");
  assert.deepEqual(p.items, []);
  p.items = ["i01", "i02", "i03", "i05", "i08"];
  offer("i18");
  assert.equal(g.phase, "replace");
  step(g, "replace:i08");
  assert.equal(p.items.length, 5);
  assert.ok(p.items.includes("i18"));
});

test("returning to Start, legendary sacrifice, lock immunity, cleanses and redistribution", () => {
  const g = pair(),
    [p, q] = g.players;
  q.gear = ["c01", "l16"];
  p.items = ["i13", "i15", "i17", "i06"];
  p.gear = ["l13"];
  step(g, "use:i13");
  assert.ok(!ids(g).some((id) => id.includes("l16")));
  step(g, "target:1:c01");
  assert.deepEqual(q.locked, ["c01"]);
  step(g, "use:i17");
  step(g, "target:1");
  assert.equal(q.movePenalty, -2);
  step(g, "use:i15");
  step(g, "target:1");
  assert.deepEqual(q.locked, []);
  assert.equal(q.movePenalty, 0);
  p.pos = 99;
  step(g, "roll", die(4));
  step(g, "return");
  assert.deepEqual([p.pos, p.atk, p.def, p.act], [1, 2, 2, 2]);
  step(g, "upgrade:atk");
  step(g, "use:i06");
  assert.deepEqual([p.atk, p.def, p.act], [1, 1, 1]);
  for (let i = 0; i < 4; i++) step(g, "upgrade:act");
  assert.equal(p.act, 5);
  assert.equal(g.upgrades.length, 0);
  const h = solo(),
    [b] = h.players;
  b.pos = 79;
  b.hp = 1;
  b.gear = ["c16", "l02"];
  step(h, "roll", die(1));
  assert.deepEqual(b.gear, ["l02"]);
  assert.equal(b.hp, 10);
  const k = solo(),
    [c] = k.players;
  c.pos = 79;
  c.hp = 1;
  c.gear = ["l13", "l02"];
  step(k, "roll", die(1));
  assert.deepEqual(c.gear, ["l02"]);
  assert.deepEqual([c.atk, c.def, c.act], [2, 2, 2]);
});

test("offline seats retain progress, skip turns and can act after reconnecting", () => {
  const g = pair(),
    [p, q] = g.players;
  q.items = ["i04"];
  q.gear = ["l03"];
  q.atk = 3;
  q.pos = 32;
  setOnline(g, "a", false);
  assert.equal(g.turn, "b");
  step(g, "roll", die(2));
  assert.equal(q.pos, 15);
  step(g, "end");
  assert.equal(g.turn, "b");
  setOnline(g, "a", true);
  step(g, "roll", die(5));
  step(g, "end");
  assert.equal(g.turn, "a");
  setOnline(g, "b", false);
  assert.deepEqual(q.items, ["i04"]);
  assert.deepEqual(q.gear, ["l03"]);
  assert.equal(q.atk, 3);
  setOnline(g, "a", false);
  assert.deepEqual(ids(g, "a"), []);
  setOnline(g, "b", true);
  assert.equal(g.turn, "b");
  assert.equal(q.online, true);
  assert.equal(p.online, false);
});

test("陷阱降低一项已升级属性，从原初之王逃跑要弃装备且无升级", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 20;
  p.atk = 2;
  p.alloc.atk = 1;
  step(g, "roll", die(1));
  assert.equal(g.board[20].type, "trap");
  assert.deepEqual(ids(g), ["upgrade:atk"]);
  step(g, "upgrade:atk");
  assert.equal(p.atk, 1);
  assert.equal(g.phase, "end");

  p.pos = 100;
  p.gear = ["l03", "l02"];
  p.items = ["i04"];
  g.phase = "finish";
  step(g, "challenge");
  step(g, "use:i04");
  assert.equal(p.pos, 1);
  assert.equal(g.phase, "deathDiscard");
  assert.equal(g.upgrades.length, 0);
  assert.ok(ids(g).includes("discard:l03"));
  step(g, "discard:l03");
  assert.deepEqual(p.gear, ["l02"]);
  assert.equal(g.phase, "end");
});

test("悟技徽章进入传说宝箱，归途传承印存活返乡时也弃置", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 81;
  choose(g, "roll", die(1));
  step(g, "check:accept");
  assert.ok(ids(g).includes("take:c13"));
  step(g, "take:c13");
  step(g, "upgrade:atk");
  p.pos = 100;
  p.gear.push("l13");
  g.phase = "finish";
  step(g, "return");
  assert.equal(p.pos, 1);
  assert.deepEqual([p.atk, p.def, p.act], [3, 2, 2]);
  assert.deepEqual(p.gear, ["c13"]);
});

test("陷阱只降低永久升级，弃置悟技徽章才会移除徽章加成", () => {
  const g = solo(),
    [p] = g.players;
  p.pos = 81;
  choose(g, "roll", die(1));
  step(g, "check:accept");
  step(g, "take:c13");
  step(g, "upgrade:act");
  p.atk = 2;
  p.alloc.atk = 1;
  p.pos = 20;
  step(g, "end");
  step(g, "roll", die(1));
  assert.deepEqual(ids(g), ["upgrade:atk"]);
  step(g, "upgrade:atk");
  assert.deepEqual([p.atk, p.act], [1, 2]);
  g.phase = "deathDiscard";
  step(g, "discard:c13");
  assert.equal(p.act, 1);
});

test("a disconnected player can resume a private choice or a wounded monster", () => {
  const g = pair(),
    [a, b] = g.players;
  step(g, "roll", die(2));
  assert.equal(g.phase, "offer");
  const choices = ids(g);
  setOnline(g, "a", false);
  assert.equal(g.turn, "b");
  assert.equal(view(g, "b").players[0].items, undefined);
  setOnline(g, "a", true);
  step(g, "roll", die(1));
  step(g, "end");
  assert.deepEqual(ids(g), choices);
  step(g, choices[0]);
  step(g, "end");
  assert.equal(g.turn, "b");
  b.pos = 18;
  b.atk = 6;
  step(g, "roll", die(1));
  step(g, "attack", die(5));
  assert.equal(g.battle.hp, 2);
  setOnline(g, "b", false);
  assert.equal(g.turn, "a");
  assert.equal(g.board[18].hp, 2);
  setOnline(g, "b", true);
  a.pos = 1;
  step(g, "roll", die(1));
  if (g.phase === "landing") step(g, "resolve");
  step(g, "end");
  assert.equal(g.battle.hp, 2);
  assert.equal(g.battle.actors[0], "b");
});

function generator(seed) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 2 ** 32;
  };
}

function chooseAdventureAction(g, snapshot) {
  const value = {
    l05: 100,
    l03: 90,
    c10: 80,
    l02: 70,
    c13: 65,
    c17: 28,
    c05: -8,
    l15: 58,
    l06: 52,
    l07: 44,
    c01: 38,
    c04: 37,
    i02: 40,
    i07: 14,
    i03: 15,
    i04: 9,
    i05: 6,
  };
  const options = snapshot.actions;
  const p = snapshot.players.find((p) => p.id === snapshot.actor);
  const byId = (id) => options.find((a) => a.id === id);
  const score = (a) => value[a.card] || 0;
  if (snapshot.phase !== "upgrade" && g.phase === "replace") {
    const worst = options
      .filter((a) => a.id.startsWith("replace:"))
      .sort((a, b) => score(a) - score(b))[0];
    return (value[g.pending.card] || 0) > score(worst)
      ? worst
      : byId("decline");
  }
  if (
    snapshot.phase !== "upgrade" &&
    (g.phase === "offer" || g.phase === "loot")
  )
    return [...options].sort((a, b) => score(b) - score(a))[0];
  const improve =
    p.atk < 3
      ? "atk"
      : p.def < Math.min(4, p.atk)
        ? "def"
        : p.act >= p.atk + 1
          ? "atk"
          : "act";
  const priority = [
    "challenge",
    ...(p.hp < 9 ? ["heal", "use:i02"] : []),
    "upgrade:" + improve,
    "rest",
    "use:i07:act",
    "use:i03",
    "attack",
    "defend",
    "confirm",
    "repeatOpening",
    "equipment",
    "end",
  ];
  return priority.map(byId).find(Boolean) || options[0];
}

for (const count of [1, 4]) {
  test(
    "a full seeded adventure reaches final-boss victory with " +
      count +
      " player(s)",
    () => {
      const g = newGame(
        Array.from({ length: count }, (_, i) => ({
          id: "p" + i,
          name: "玩家" + i,
        })),
      );
      const rng = generator(13244);
      let actionsTaken = 0;
      while (!g.winner && actionsTaken < 12000) {
        const id = actor(g);
        const snapshot = view(g, id);
        const move = chooseAdventureAction(g, snapshot);
        assert.ok(move, "missing legal action during " + g.phase);
        act(g, id, move.id, rng);
        actionsTaken++;
      }
      assert.ok(
        g.winner,
        "failed to reach victory within the test budget: " +
          JSON.stringify({
            round: g.round,
            phase: g.phase,
            battle: g.battle?.monster,
            log: g.log.slice(-6),
          }),
      );
      assert.equal(g.players.find((p) => p.id === g.winner).pos, 100);
      for (const p of g.players) assert.deepEqual(view(g, p.id).actions, []);
    },
  );
}
